class Node:
    def __init__(self, node_type, value=None, left=None, right=None):
        self.type = node_type   # 'operator' or 'operand'
        self.value = value      # e.g., '>', 'age', 'Sales', 30
        self.left = left        # Left child Node
        self.right = right      # Right child Node

    def to_dict(self):
        """Convert the AST node to a dictionary for easy serialization."""
        node_dict = {
            "type": self.type,
            "value": self.value
        }
        if self.left:
            node_dict["left"] = self.left.to_dict()
        if self.right:
            node_dict["right"] = self.right.to_dict()
        return node_dict


def create_rule(rule_str):
    # Placeholder function to parse rule string into AST
    # For simplicity, we're just going to manually build the tree
    # You would implement a proper parser here

    # Example rule: "age > 30 AND department = 'Sales'"
    if rule_str == "age > 30 AND department = 'Sales'":
        root = Node("operator", "AND")
        root.left = Node("operand", ("age", ">", 30))
        root.right = Node("operand", ("department", "=", "Sales"))
        return root
    elif rule_str == "age < 25 AND department = 'Marketing'":
        root = Node("operator", "AND")
        root.left = Node("operand", ("age", "<", 25))
        root.right = Node("operand", ("department", "=", "Marketing"))
        return root
    return None


def combine_rules(rule_asts):
    # Combining multiple ASTs with AND operator at the root
    if len(rule_asts) == 1:
        return rule_asts[0]
    
    root = Node("operator", "AND")
    root.left = rule_asts[0]
    root.right = combine_rules(rule_asts[1:])
    return root


def evaluate_node(node, data):
    # Evaluate the condition or operator node recursively
    if node.type == "operand":
        attr, op, value = node.value
        if op == ">":
            return data[attr] > value
        elif op == "<":
            return data[attr] < value
        elif op == "=":
            return data[attr] == value
    elif node.type == "operator":
        if node.value == "AND":
            return evaluate_node(node.left, data) and evaluate_node(node.right, data)
        elif node.value == "OR":
            return evaluate_node(node.left, data) or evaluate_node(node.right, data)
    return False


def evaluate_rule(ast, data):
    return evaluate_node(ast, data)

