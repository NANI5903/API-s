# test_cases.py
from ast_rule_engine import create_rule, combine_rules, evaluate_rule

def run_tests():
    # Create rule test
    rule1 = create_rule("age > 30 AND department = 'Sales'")
    rule2 = create_rule("age < 25 AND department = 'Marketing'")

    assert rule1 is not None
    assert rule2 is not None

    # Combine rules test
    combined_ast = combine_rules([rule1, rule2])
    assert combined_ast is not None

    # Evaluate rule test
    data1 = {"age": 35, "department": "Sales", "salary": 60000, "experience": 3}
    data2 = {"age": 22, "department": "Marketing", "salary": 25000, "experience": 2}

    assert evaluate_rule(combined_ast, data1) == True
    assert evaluate_rule(combined_ast, data2) == True

    print("All tests passed!")

if __name__ == '__main__':
    run_tests()
