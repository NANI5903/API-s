# database.py
from flask import Flask
from models import db, Rule

def init_db(app):
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite3'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)
    with app.app_context():
        db.create_all()  # Create tables

def add_rule(rule_string):
    rule = Rule(rule_string=rule_string)
    db.session.add(rule)
    db.session.commit()

def get_rules():
    return Rule.query.all()
