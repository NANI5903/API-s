from flask import Flask, request, jsonify
from ast_rule_engine import create_rule, combine_rules, evaluate_rule
from database import init_db, add_rule, get_rules
from models import db

app = Flask(__name__)
init_db(app)

@app.route('/')
def home():
    return "Welcome to the Rule Engine API. Use /create_rule, /combine_rules, /evaluate_rule, or /get_rules."

# Endpoint to create and store a rule
@app.route('/create_rule', methods=['POST'])
def create_rule_api():
    rule_string = request.json.get('rule')
    rule_ast = create_rule(rule_string)
    
    if rule_ast:
        add_rule(rule_string)
        return jsonify({"message": "Rule created successfully", "rule_ast": rule_ast.to_dict()}), 201
    else:
        return jsonify({"error": "Invalid rule format"}), 400

# Endpoint to combine all rules and return the combined AST in JSON format
@app.route('/combine_rules', methods=['GET'])
def combine_rules_api():
    rules = get_rules()  # Fetch rules from the database
    rule_asts = [create_rule(rule.rule_string) for rule in rules]
    combined_ast = combine_rules(rule_asts)
    
    if combined_ast:
        # Convert the combined AST to a JSON-friendly format using the to_dict() method
        return jsonify({"combined_ast": combined_ast.to_dict()}), 200
    else:
        return jsonify({"error": "No rules found or invalid rules"}), 400

# Endpoint to evaluate a rule with given data
@app.route('/evaluate_rule', methods=['POST'])
def evaluate_rule_api():
    rule_string = request.json.get('rule')
    data = request.json.get('data')
    
    rule_ast = create_rule(rule_string)
    if rule_ast and data:
        result = evaluate_rule(rule_ast, data)
        return jsonify({"result": result}), 200
    else:
        return jsonify({"error": "Invalid data or rule"}), 400

# New endpoint to get all rules stored in the database
@app.route('/get_rules', methods=['GET'])
def get_all_rules():
    rules = get_rules()  # Fetch rules from the database
    rule_list = [{"id": rule.id, "rule_string": rule.rule_string} for rule in rules]
    
    return jsonify({"rules": rule_list}), 200

if __name__ == '__main__':
    app.run(debug=True)
